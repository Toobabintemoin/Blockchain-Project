// class BlockChainNode{

//     constructor(branch){
//         this.branch = branch
//     }
// }

// module.exports = BlockChainNode
class BlockChainNode{

    constructor(url){
        this.url = url
    }
}

module.exports = BlockChainNode