class DrivingRecordSmartContract {
    apply(transactin, blocks) {
    // go through all blocks
        blocks.forEach(function(block){
            block.transaction.forEach(function(trans){
            if(transactin.driverLicenseNumber == trans.driverLicenseNumber) {
            console.log("here")
            transactin.noOfVoilations += 1
                if(transactin.noOfVoilations > 5) {
                    transactin.isDriverLicenseSuspended = true
    }
    }
    })
    })
    }
    }

module.exports = DrivingRecordSmartContract