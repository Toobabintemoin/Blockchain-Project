// let Block = require('./block')
// let Blockchain=require('./blockchain')
// let Data =require('./data')
// let Blockchainbranches = require('./branches')

// let express = require(`express`)
// let app = express()
// let port = 2001;
// const bodyParser = require(`body-parser`)

// let inputs =[]
// let branches = []

// process.argv.forEach(function(val,index,array){
//     port = array[2]
// })

// if (port == undefined){
//     port = 2001
// }

// // =========== it was in block code before we were doing work statically ,,,,
// // now it should be out because we are doing work through postman/server ================

// let genesisBlock = new Block()
// let blockchain = new Blockchain(genesisBlock)

// // for using body-parser=========
// app.use(bodyParser.json())

// app.get('/',function(req,res){
//     res.send('WELCOME TO SUPERMARKET')
// })

// // ================ to mine/add new blocks through postman =====================
// app.get('/mining' , function(req,res){
//     let block = blockchain.getNextBlock(inputs)
//     blockchain.addBlock(block)
//     res.json(block)
// })

// app.post('/branches/registration',function(req,res){
//     let branchesLists = req.body.branches
//     branchesLists.forEach(function(branchDictionary){
//         let branch = new Blockchainbranches (branchDictionary['branch'])
//         branches.push(branch)
//     })
//     res.json(branches)
// })

// app.get('/branches',function(req,res){
//     res.json(nodes)
// })

// // ================== to see the final chain of blocks or blockchain==================
// app.get('/blockchain',function(req,res){
//     res.json(blockchain)
// })


// // // =========== to give data from Server and see on server =======================
// app.post('/data', function(req,res){
//     let Farm = req.body.Farm
//     let Storage_Warehouse = req.body.Storage_Warehouse
//     let Transport = req.body.Transport
//     let Processing = req.body.Processing

//     console.log(Farm,Storage_Warehouse,Transport,Processing);

//     let input = new Data(Farm,Storage_Warehouse,Transport,Processing)

//     inputs.push(input)

//     res.json(inputs)
// })

// app.listen(port,()=>{
//     console.log(`server has started on ${port}`)
// })
let Block = require('./block')
let Blockchain=require('./blockchain')
let Transaction=require('./transaction')
const BlockChainNode = require('./blockchain_node')
const DrivingRecordSmartContract = require('./smartcontracts')
let sha256 = require('sha256')
let fetch = require('node-fetch')
let express = require(`express`)
const mongoose = require('mongoose');
let app = express()
const bodyParser = require(`body-parser`)
var port = 1234;
var FIR =require('./model/Fir');

mongoose.connect("mongodb://localhost/myapp",{useNewUrlParser:true})
var db =mongoose.connection('error', err => {
    logError(err);
  });
db.on();

process.argv.forEach(function(val,index,array){
    port = array[2]
})

if (port == undefined){
    port = 1234
}

let transactions =[]
let nodes = []


// =========== it was in block code before we were doing work statically ,,,,
// now it should be out because we are doing work through postman/server ================

let genesisBlock = new Block()
let blockchain = new Blockchain(genesisBlock)
// const fir = mongoose.Schema({
//     "Index":blockchain.index,
//     "Hash":String,
//     "PreviousHash":String,
//     "Nonce":String,
//     "Timestamp":Date(),
//     "Transaction":[
//         {
//             "CrimanalName":String,
//             "Date":new Date(),
//         }
//     ]
// }

// for using body-parser=========
app.use(bodyParser.json())

app.get('/',function(req,res){
    res.send('hello blockchain')
})


// ================ to mine/add new blocks through postman =====================
app.get('/mine' , function(req,res){
    let block = blockchain.getNextBlock(transactions)
    blockchain.addBlock(block)
    res.json(block)
})

// ============ to register nodes==================================
app.post ('/nodes/register', function(req,res){
    let nodesLists = req.body.urls
    nodesLists.forEach(function(nodeDictionary){
        let node = new BlockChainNode(nodeDictionary['url'])
        nodes.push(node)
    })
    res.json(nodes)
})

// ================ to see nodes =======================
app.get('/nodes', function(req,res){
    res.json(nodes)
})

app.get('/resolve', function(req,res){
    console.log("/resolve route");
    nodes.forEach(node => {
        fetch('http://' + node.url + '/blockchain')
        .then(function(response){
            return response.json()
        })

        .then(function(otherNodeBlockChain){
            if(blockchain.blocks.length < otherNodeBlockChain){
                blockchain = otherNodeBlockChain
            }
        })
    })
})

// driving-records/TX1234
// driving-records/CA1234
app.get("/driving-records/:drivingLicenseNumber",function(req,res){
    let drivingLicenseNumber = sha256(req.params.drivingLicenseNumber)
    let transactions = blockchain.transactionsByDrivingLicenseNumber(drivingLicenseNumber)
    res.json(transactions)
    })
app.post('/transactions',function(req,res){
    console.log(transactions)
    let drivingRecordSmartContract = new DrivingRecordSmartContract()
    console.log(req.body.driverLicenseNumber);
    let driverLicenseNumber = sha256(req.body.driverLicenseNumber)
    let voilationDate = req.body.voilationDate
    let voilationType = req.body.voilationType

    let transaction = new Transaction(driverLicenseNumber,voilationDate,voilationType)   
    drivingRecordSmartContract.apply(transaction,blockchain.blocks)
    transactions.push(transaction)
    res.json(transactions)
    })
    
// ================== to see the final chain of blocks or blockchain==================
app.get('/blockchain',function(req,res){
    res.json(blockchain)
})

app.listen(port,()=>{
    console.log(`server has started on ${port}`)
   })


















