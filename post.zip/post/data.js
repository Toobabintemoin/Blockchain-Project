// class Data{
    
//     constructor(Farm,Storage_Warehouse, Transport, Processing){
//         this.farm = Farm
//         this.storage_warehouse = Storage_Warehouse
//         this.transport = Transport
//         this.processing = Processing
//     }
    
    
// }
// module.exports=Data

class Transaction {
    constructor(FirNum,Disc,Date,Act,Section,PlaceOfOccurance,CriminalName,CriminalCNIC,CriminalAge,CriminalProvince,
             CriminalContact,CriminalAddress,CriminalNationality,Crime,VictimName,VictimCNIC,VictimAge,VictimProvince,VictimContact,VictimAddress,VictimNationality) {
    this.FirNum = FirNum
    this.Disc = Disc
    this.Date = Date
    this.Act = Act
    this.Section = Section
    this.PlaceOfOccurance = PlaceOfOccurance
    this.CriminalName = CriminalName
    this.CriminalCNIC = CriminalCNIC
    this.CriminalAge = CriminalAge
    this.CriminalProvince = CriminalProvince
    this.CriminalContact = CriminalContact
    this.CriminalAddress = CriminalAddress
    this.CriminalNationality = CriminalNationality
    this.Crime = Crime
    this.VictimName = VictimName
    this.VictimCNIC = VictimCNIC
    this.VictimAge = VictimAge
    this.VictimProvince = VictimProvince
    this.CriminalContact = VictimProvince
    this.VictimContact = VictimContact
    this.VictimAddress = VictimAddress
    this.VictimNationality = VictimNationality
    this.noOfVoilations = 1
    this.isDriverLicenseSuspended = false
    }
}
module.exports = Transaction

















