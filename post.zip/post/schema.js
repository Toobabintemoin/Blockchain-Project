const mongoose = require('mongoose');

const fir = mongoose.Schema({
    "Index":Number,
    "Hash":String,
    "PreviousHash":String,
    "Nonce":String,
    "Timestamp":Date(),
    "Transaction":[
        {
            "CrimanalName":String,
            "Date":new Date(),
        }
    ]
}
module.exports = mongoose.model("FIR",fir);