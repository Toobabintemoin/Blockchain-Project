// var arr_names = ["ghous", "ali", "sara", "zara"]

// console.log(`welcome ${arr_names[0]}`);

// var arr = []
// arr[0] = "cat";
// arr[1] = "dog";
// arr[2] = "car";

// console.log(arr);

// var names = new Array("ghous", "ali", "sara", "zara")

// for(var i=0; i<names.length; i++){
//     console.log(names[i]);
// }

// var arr_name = ["ghous", "ali", "sara", "zara"]
// var arr_num = [0,1,2,3,4,5]

// var concatenate = arr_name.concat(arr_num)
// console.log(concatenate, arr_name.length);

// var coo = concatenate.join(" ,")
// console.log(coo);
// var num = [0,1,2,3,4,5,6]
// var coo = arr_name.shift()
// var foo = arr_name.shift()
// var foo = num.unshift(11,12)
// console.log(foo);
// console.log(num);
// console.log(coo);
// console.log(foo);
// console.log(arr_name);

// var abc = [1,2,3,4,5]

// var c = abc.splice(0,2,2)
// console.log(c);
// // console.log(abc);
// function abc (element){
//     return (element>=5)
// }

// var arr = [2,4,6,7,8,10]
// var c = arr.filter(abc)
// // var myArr = arr.filter(v => v/2 === 0 );
// console.log(c);
// console.log(myArr);
// console.log(arr);

// var materials = ["hydrogen","helium" , "lithium","beryllium"];
// console.log(materials.map(materials => materials.length));

// var num = 5 
// var factorial = 1

// for(let i = num ; i >= 1 ; i--){
//     // factorial *= i
//      factorial = factorial * i
// }
// console.log(factorial);

// var obj = {
//     a : 1,
//     b : 2
// }
// for(var prop in obj){
//     console.log(obj[prop]);
// }

// var arr = [23,34,35,35]
// for(var val of arr){
//     console.log(val);
// }


// var i = 1
// while(i<=10){
//     if(i % 5 == 0){
//         console.log(i);
//         break
//     }
//     i++
// }

//  var a = {
//      name : "tom",
//      id : 5545
//  }
//  var copy = Object.assign({}, a)
//  console.log(copy);

// for(var val in copy){
//     console.log(copy[val]);
// // }
// passward = 54321;
// names = "shah"

// function passward(pass){
//     for(i = 0 ; i < pass.lenghth ; i++){

//     }
// }
// function names (pname){
//     console.log(i);
//     for(i=0 ; i < pname.lenghth; i++){

//     }
// }



num1 = 5
function cal(){
    num1 = 10;
    num2 = 5
    num3 = num1 * num2
    console.log(num3 ); 
}
cal()



















































// abc.push(11,12,13)
// // abc.pop()
// // abc.pop()

// console.log(abc);

// let a = null ;
// console.log(a);

// let b = undefined;
// console.log(b);
// console.log(null == undefined);
// console.log(null === undefined);


























